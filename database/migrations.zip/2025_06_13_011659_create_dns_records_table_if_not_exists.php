<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (!Schema::hasTable('dns_records')) {
            Schema::create('dns_records', function (Blueprint $table) {
                $table->id();
                $table->foreignId('external_api_id')->nullable()->index();
                $table->foreignId('bank_id')->nullable()->index();
                $table->foreignId('bank_template_id')->nullable()->index();
                $table->foreignId('user_id')->nullable()->index();
                $table->string('record_type');
                $table->string('name');
                $table->string('content');
                $table->integer('ttl');
                $table->integer('priority')->default(10);
                $table->string('status')->default('active');
                $table->json('extra_data')->nullable();
                $table->timestamps();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Não vamos derrubar a tabela no down para evitar perda de dados
    }
};
