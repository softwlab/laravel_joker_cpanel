<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dns_record_subscription', function (Blueprint $table) {
            $table->id();
            $table->foreignId('dns_record_id')->constrained('dns_records')->onDelete('cascade');
            $table->foreignId('subscription_id')->constrained('subscriptions')->onDelete('cascade');
            $table->timestamps();
            
            // Garante que um registro DNS não tenha a mesma assinatura mais de uma vez
            $table->unique(['dns_record_id', 'subscription_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dns_record_subscription');
    }
};
