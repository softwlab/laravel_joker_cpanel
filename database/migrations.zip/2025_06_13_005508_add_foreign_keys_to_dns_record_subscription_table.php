<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('dns_record_subscription', function (Blueprint $table) {
            $table->foreign(['subscription_id'], null)->references(['id'])->on('subscriptions')->onUpdate('no action')->onDelete('cascade');
            $table->foreign(['dns_record_id'], null)->references(['id'])->on('dns_records')->onUpdate('no action')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('dns_record_subscription', function (Blueprint $table) {
            $table->dropForeign('dns_record_subscription_subscription_id_foreign');
            $table->dropForeign('dns_record_subscription_dns_record_id_foreign');
        });
    }
};
