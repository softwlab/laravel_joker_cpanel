<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cloudflare_domain_usuario', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('cloudflare_domain_id');
            $table->integer('usuario_id');
            $table->string('status')->default('active')->index();
            $table->text('config')->nullable();
            $table->text('notes')->nullable();
            $table->dateTime('created_at')->nullable();
            $table->dateTime('updated_at')->nullable();

            $table->index(['cloudflare_domain_id', 'usuario_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cloudflare_domain_usuario');
    }
};
